import React from 'react';
import { useNavigate } from 'react-router-dom';
import './Landing.css';

const Landing = () => {
  const navigate = useNavigate();

  return (
    <div className="landing-container">
      <div className="landing-content">
        <h1 className="landing-title">Welcome to BlogCMS platform</h1>
        <p className="landing-subtitle">Start sharing your perspective today</p>
        
        <div className="landing-buttons">
          <button 
            className="btn btn-primary btn-lg landing-btn"
            onClick={() => navigate('/home')}
          >
            Guest User
          </button>
          
          <button 
            className="btn btn-success btn-lg landing-btn"
            onClick={() => navigate('/register')}
          >
            Register
          </button>
          
          <button 
            className="btn btn-outline-primary btn-lg landing-btn"
            onClick={() => navigate('/login')}
          >
            Login
          </button>
        </div>

        <div className="landing-features mt-5">
          <h3>Features:</h3>
          <ul className="list-unstyled">
            <li> 👁️ View blog posts as a Guest</li>
            <li> 📝 Create and Publish Posts</li>
            <li> 🅱️ Rich Text Editor</li>
            <li> 📁 Content Management</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default Landing;