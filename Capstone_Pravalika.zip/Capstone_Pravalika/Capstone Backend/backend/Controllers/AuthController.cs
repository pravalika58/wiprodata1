﻿// Controllers/AuthController.cs
using capstone.Data;
using capstone.DTOs;
using capstone.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;

namespace capstone.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly IConfiguration _configuration;
        private readonly PasswordHasher<User> _passwordHasher;

        public AuthController(AppDbContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
            _passwordHasher = new PasswordHasher<User>();
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register(RegisterDto registerDto)
        {
            if (await _context.Users.AnyAsync(u => u.Username == registerDto.Username))
                return BadRequest("Username already exists");

            if (await _context.Users.AnyAsync(u => u.Email == registerDto.Email))
                return BadRequest("Email already exists");

            var user = new User
            {
                Username = registerDto.Username,
                Email = registerDto.Email,
                Role = "User"
            };

            // Hash the password
            user.PasswordHash = _passwordHasher.HashPassword(user, registerDto.Password);

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            return Ok(new { message = "User registered successfully" });
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login(LoginDto loginDto)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Username == loginDto.Username);
            if (user == null)
                return BadRequest("User not found");

            // Verify the password
            var result = _passwordHasher.VerifyHashedPassword(user, user.PasswordHash, loginDto.Password);
            if (result == PasswordVerificationResult.Failed)
                return BadRequest("Wrong password");

            var token = CreateToken(user);

            return Ok(new
            {
                token,
                user = new
                {
                    user.Id,
                    user.Username,
                    user.Email,
                    user.Role
                }
            });
        }


        private string CreateToken(User user)
        {
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                new Claim(ClaimTypes.Name, user.Username),
                new Claim(ClaimTypes.Role, user.Role)
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(
                _configuration.GetSection("Jwt:Key").Value));

            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha512Signature);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(claims),
                Expires = DateTime.Now.AddDays(1),
                SigningCredentials = creds
            };

            var tokenHandler = new JwtSecurityTokenHandler();
            var token = tokenHandler.CreateToken(tokenDescriptor);

            return tokenHandler.WriteToken(token);
        }

    }
}












// Controllers/AuthController.cs
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using BlogCMS.Data;
//using BlogCMS.Models;
//using BlogCMS.DTOs;
//using System.Security.Cryptography;
//using System.Text;
//using System.IdentityModel.Tokens.Jwt;
//using Microsoft.IdentityModel.Tokens;
//using System.Security.Claims;
//using Microsoft.AspNetCore.Identity;

//namespace BlogCMS.Controllers
//{
//    [ApiController]
//    [Route("api/[controller]")]
//    public class AuthController : ControllerBase
//    {
//        private readonly AppDbContext _context;
//        private readonly IConfiguration _configuration;
//        private readonly PasswordHasher<User> _passwordHasher;

//        public AuthController(AppDbContext context, IConfiguration configuration)
//        {
//            _context = context;
//            _configuration = configuration;
//            _passwordHasher = new PasswordHasher<User>();
//        }

//        // ... existing login and register methods ...

//        [HttpPost("forgot-password")]
//        public async Task<IActionResult> ForgotPassword(ForgotPasswordDto forgotPasswordDto)
//        {
//            try
//            {
//                var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == forgotPasswordDto.Email);
//                if (user == null)
//                {
//                    // Don't reveal that the user doesn't exist for security reasons
//                    return Ok(new { message = "If the email exists, a password reset link has been sent." });
//                }

//                // Generate reset token
//                var resetToken = Convert.ToBase64String(RandomNumberGenerator.GetBytes(64));
//                user.ResetToken = resetToken;
//                user.ResetTokenExpires = DateTime.UtcNow.AddHours(1); // Token valid for 1 hour

//                _context.Users.Update(user);
//                await _context.SaveChangesAsync();

//                // In a real application, you would send an email here
//                // For demo purposes, we'll return the token in the response
//                return Ok(new
//                {
//                    message = "If the email exists, a password reset link has been sent.",
//                    resetToken = resetToken // Remove this in production - only for demo
//                });
//            }
//            catch (Exception ex)
//            {
//                return StatusCode(500, $"Internal server error: {ex.Message}");
//            }
//        }

//        [HttpPost("reset-password")]
//        public async Task<IActionResult> ResetPassword(ResetPasswordDto resetPasswordDto)
//        {
//            try
//            {
//                var user = await _context.Users.FirstOrDefaultAsync(u =>
//                    u.Email == resetPasswordDto.Email &&
//                    u.ResetToken == resetPasswordDto.Token &&
//                    u.ResetTokenExpires > DateTime.UtcNow);

//                if (user == null)
//                {
//                    return BadRequest("Invalid or expired reset token.");
//                }

//                // Reset password
//                user.PasswordHash = _passwordHasher.HashPassword(user, resetPasswordDto.NewPassword);
//                user.ResetToken = null;
//                user.ResetTokenExpires = null;

//                _context.Users.Update(user);
//                await _context.SaveChangesAsync();

//                return Ok(new { message = "Password has been reset successfully." });
//            }
//            catch (Exception ex)
//            {
//                return StatusCode(500, $"Internal server error: {ex.Message}");
//            }
//        }

//        // ... existing methods ...
//    }
//}